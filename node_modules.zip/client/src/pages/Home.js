import React from "react";
import LoginPage from "./LoginPage";




const Home = () => {
  return (
    <div>
      <h1>ระบบสารสนเทศเพื่อการจัดทำงบประมาณ ขององค์กรปกครองส่วนท้องถิ่น</h1>
      <LoginPage />





 
    </div>
  );
};

export default Home;
