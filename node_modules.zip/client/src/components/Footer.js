import React from "react";
import './Footer.css';

const Footer = () => {
  return (
    <div className="footer">
      <a href="">เพื่อจัดทำงบประมาณขององค์กรปกครองส่วนท้องถิ่น</a> <br />

    </div>
  );
}

export default Footer;
