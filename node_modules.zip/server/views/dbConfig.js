module.exports = {
    user: "root",
    host: "localhost",
    password: "root",
    database: "bbl"
};
